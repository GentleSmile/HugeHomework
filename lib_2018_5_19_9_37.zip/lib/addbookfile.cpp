#include "addbookfile.h"
#include "ui_addbookfile.h"
#include <QDir>
#include <QFileDialog>


AddBookFile::AddBookFile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddBookFile)
{
    ui->setupUi(this);
}

AddBookFile::~AddBookFile()
{
    delete ui;
}

void AddBookFile::on_SelectBtn_clicked()
{
    QString directory =
            QDir::toNativeSeparators(QFileDialog::getOpenFileName(this,tr("选择导入文件"),QDir::currentPath()));
    if(!directory.isEmpty())
    {
        if(ui->DirectryBox->findText(directory)==-1)
            ui->DirectryBox->addItem(directory);
        ui->DirectryBox->setCurrentIndex(ui->DirectryBox->findText(directory));

    }
}
