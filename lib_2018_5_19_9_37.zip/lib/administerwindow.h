#ifndef ADMINISTERWINDOW_H
#define ADMINISTERWINDOW_H

#include <QDialog>

namespace Ui {
class AdministerWindow;
}

class AdministerWindow : public QDialog
{
    Q_OBJECT

public:
    explicit AdministerWindow(QWidget *parent = 0);
    ~AdministerWindow();

private slots:

    void on_AddReader_Btn_clicked();

    void on_FromFileBtn_clicked();

    void on_AddBookBtn_clicked();

    void on_BookFileBtn_clicked();

private:
    Ui::AdministerWindow *ui;
};

#endif // ADMINISTERWINDOW_H
