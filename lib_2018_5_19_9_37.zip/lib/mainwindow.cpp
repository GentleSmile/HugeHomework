#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "signin.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(this->ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(ShowWindow()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

MainWindow::ShowWindow()
{
    Dialog d;
    d.show();
    return d.exec();
}

void MainWindow::ChangeLable()
{
    login=true;
    this->ui->label->setText(tr("已登陆！"));

}


MainWindow::on_UserLogIn_clicked()
{
    SignIn *a=new SignIn();
    connect(a,SIGNAL(HasLogged()),this,SLOT(ChangeLable()));
    a->show();
    return a->exec();

}
