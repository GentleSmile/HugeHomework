#include "administerwindow.h"
#include "ui_administerwindow.h"
#include "adduser.h"
#include "adduserfile.h"
#include "addbook.h"
#include "addbookfile.h"
AdministerWindow::AdministerWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdministerWindow)
{
    ui->setupUi(this);
}

AdministerWindow::~AdministerWindow()
{
    delete ui;
}


void AdministerWindow::on_AddReader_Btn_clicked()
{
    AddUser * a=new AddUser();
    int ret= a->exec();
}

void AdministerWindow::on_FromFileBtn_clicked()
{
    AddUserFile *a=new AddUserFile();
    int ret=a->exec();
}

void AdministerWindow::on_AddBookBtn_clicked()
{
    AddBook *a=new AddBook();
    int ret=a->exec();

}


void AdministerWindow::on_BookFileBtn_clicked()
{
    AddBookFile *a=new AddBookFile();
    int ret=a->exec();
}
