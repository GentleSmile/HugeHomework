#include "adduserfile.h"
#include "ui_adduserfile.h"
#include <QDir>
#include <QFileDialog>

AddUserFile::AddUserFile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddUserFile)
{
    ui->setupUi(this);
}

AddUserFile::~AddUserFile()
{
    delete ui;
}

void AddUserFile::on_SelectBtn_clicked()
{
    QString directory =
            QDir::toNativeSeparators(QFileDialog::getOpenFileName(this,tr("选择导入文件"),QDir::currentPath()));
    if(!directory.isEmpty())
    {
        if(ui->DirectryBox->findText(directory)==-1)
            ui->DirectryBox->addItem(directory);
        ui->DirectryBox->setCurrentIndex(ui->DirectryBox->findText(directory));

    }
}
