#ifndef ADDBOOKFILE_H
#define ADDBOOKFILE_H

#include <QDialog>

namespace Ui {
class AddBookFile;
}

class AddBookFile : public QDialog
{
    Q_OBJECT

public:
    explicit AddBookFile(QWidget *parent = 0);
    ~AddBookFile();

private slots:
    void on_SelectBtn_clicked();

private:
    Ui::AddBookFile *ui;
};

#endif // ADDBOOKFILE_H
