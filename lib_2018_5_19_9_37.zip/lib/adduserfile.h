#ifndef ADDUSERFILE_H
#define ADDUSERFILE_H

#include <QDialog>

namespace Ui {
class AddUserFile;
}

class AddUserFile : public QDialog
{
    Q_OBJECT

public:
    explicit AddUserFile(QWidget *parent = 0);
    ~AddUserFile();

private slots:
    void on_SelectBtn_clicked();

private:
    Ui::AddUserFile *ui;
};

#endif // ADDUSERFILE_H
