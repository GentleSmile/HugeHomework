#include "adduser.h"
#include "ui_adduser.h"
#include<QString>
#include<QMessageBox>
AddUser::AddUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddUser)
{
    ui->setupUi(this);
}

AddUser::~AddUser()
{
    delete ui;
}

void AddUser::on_OK_Btn_clicked()
{
    QString ID=this->ui->stu_ID->text();
    QString name=this->ui->stu_Name->text();
    QString password=this->ui->stu_Password->text();
    QMessageBox q;
    q.setIcon(QMessageBox::Question);
    q.setWindowTitle(tr("确认信息"));
    q.setText(ID+"\n"+name+"\n"+password);
    q.addButton("确定",QMessageBox::YesRole);
    q.addButton("取消",QMessageBox::NoRole);
    q.show();
    int ret=q.exec();
//    QMessageBox::question(this,"确认信息",ID+"\n"+name+"\n"+password,"确定","取消");
    if(!ret)
    this->close();

}

void AddUser::on_Cancel_Btn_clicked()
{
    this->close();
}
