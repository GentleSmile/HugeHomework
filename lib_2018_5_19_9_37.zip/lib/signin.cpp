#include "signin.h"
#include "ui_signin.h"
#include<QMessageBox>
#include "administerwindow.h"
SignIn::SignIn(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SignIn)
{
    ui->setupUi(this);
}

SignIn::~SignIn()
{
    delete ui;
}

void SignIn::on_Cancel_Btn_clicked()
{
    this->close();
}

void SignIn::on_OK_Btn_clicked()
{
    if(this->ui->UserName->text()=="Admin"&&this->ui->Password->text()=="password")
    {
        this->close();
        AdministerWindow *a=new AdministerWindow();
        int ret=a->exec();
    }

    else if(this->ui->UserName->text()=="User"&&this->ui->Password->text()=="password")
    {
        QMessageBox q;
        q.setWindowTitle(tr("提示"));
        q.setText(tr("登陆成功"));
        q.addButton("确定",QMessageBox::YesRole);
        q.show();
        int ret=q.exec();
        emit HasLogged();
        this->close();

    }


    else
    {
       QMessageBox a;
       a.setText(tr("用户名或密码错误"));
       QApplication::setQuitOnLastWindowClosed(false);
       int ret=a.exec();
    }

}
